if (window.captchaObjEventsV4.onSuccess !== undefined) {
    window.captchaObjEventsV4.onSuccess();
}
